<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="jumbotron text-center bg-warning orifont">
        <h1><img src="<?php echo e(asset('img/logo.png')); ?>">Register<img src="<?php echo e(asset('img/logo.png')); ?>"></h1>
    </div>
    <div class="row d-flex justify-content-center">
        
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('firstname') ? ' has-error' : ''); ?>">
                            <label for="firstname" class="lead orifont control-label">Firstame</label>

                            <div >
                                <input id="firstname" type="text" class="form-control" name="firstname" value="<?php echo e(old('firstname')); ?>" required autofocus placeholder="Enter firstname">

                                <?php if($errors->has('firstname')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('firstname')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                         <div class="form-group<?php echo e($errors->has('lastname') ? ' has-error' : ''); ?>">
                            <label for="lastname" class="lead orifont control-label">Lastname</label>

                            <div >
                                <input id="lastname" type="text" class="form-control" name="lastname" value="<?php echo e(old('lastname')); ?>" required autofocus placeholder="Enter lastname">

                                <?php if($errors->has('lastname')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('lastname')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                         <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                            <label for="username" class="lead orifont control-label">Username</label>

                            <div >
                                <input id="username" type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" required autofocus placeholder="Enter username">

                                <?php if($errors->has('username')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="lead orifont control-label">E-Mail Address</label>

                            <div >
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required placeholder="Enter e-mail address">

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="lead orifont control-label">Password</label>

                            <div >
                                <input id="password" type="password" class="form-control" name="password" required placeholder="Enter password">

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class="lead orifont control-label">Confirm Password</label>

                            <div >
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required placeholder="Confirm password">
                            </div>
                        </div>

                        <div class="form-group">
                            <div >
                                <button type="submit" class="lead orifont btn btn-primary">
                                    Register
                                </button>
                            </div>
                        </div>
                    </form>
                
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>