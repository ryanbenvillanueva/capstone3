<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-heading">
        <h4 class="text-center">Dashboard</h4>
    </div>

    <div class="card-body">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>

        <p class="text-center lead">Welcome!</p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>