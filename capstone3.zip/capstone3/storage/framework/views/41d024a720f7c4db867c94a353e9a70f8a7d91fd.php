<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="jumbotron text-center bg-warning orifont m-0">
		<h1><img src="<?php echo e(asset('img/logo.png')); ?>">Blog<img src="<?php echo e(asset('img/logo.png')); ?>"></h1>
	</div>
</div>

<div class="row">
	<div class="container">
		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="card col-sm-12 col-md-12 col-lg-8">
			<img src="<?php echo e($post->img_path); ?>" class="card-img-top">
			<div class="card-body">
				<h4 class="card-title"><?php echo e($post->title); ?></h4>
				<p class="card-text"><?php echo $post->content; ?></p>
				<a href="/posts/<?php echo e($post->id); ?>" class="btn btn-primary">Read More</a>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<div class="card col-sm-12 col-md-12 col-lg-4"></div>
	</div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>