<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, shrink-to-fit=no">
	<meta http-equiv="X-UA-Compatible" content="IE-Edge">

	<!-- CSRF Token -->
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<!-- my favicon -->
	<link rel="icon" type="image/gif/png" href="<?php echo e(asset('img/logo.png')); ?>">
	<!-- bootstrap css -->
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO"
	crossorigin="anonymous">
	<!-- custom css -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
	<!-- font awesome -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz"
	crossorigin="anonymous">
	<!-- animate css -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/animate.css')); ?>">
	<!-- google font nunito sans-->
	<link href="https://fonts.googleapis.com/css?family=Nunito+Sans" rel="stylesheet">
	<!-- Toastr Notification css-->
	<link href="<?php echo e(asset('css/toastr.min.css')); ?>" rel="stylesheet">

	<title><?php echo e(config('app.name', 'FoldingBen')); ?></title>
</head>

<body>
	

	<nav class="navbar navbar-expand-lg navbar-dark bg-danger sticky-top">
		<a class="navbar-brand btn btn-outline-warning orifont" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('img/logo.png')); ?>"><?php echo e(config('app.name',
			'FoldingBen')); ?></a>
			<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse text-center" id="navbar">
				<ul class="nav navbar-nav ml-auto">
					<!-- Authentication Links -->
					<?php if(auth()->guard()->guest()): ?>
					<li class="nav-item"><a class="nav-link lead orifont" href="<?php echo e(route('login')); ?>">Login</a></li>
					<li class="nav-item"><a class="nav-link lead orifont" href="<?php echo e(route('register')); ?>">Register</a></li>
					<?php else: ?>
					<li class="nav-item dropdown">
						<a class="nav-link text-light lead orifont" href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
						aria-expanded="false" aria-haspopup="true" v-pre>
						<?php echo e(Auth::user()->firstname); ?> <span class="caret"></span>
					</a>

					<ul class="dropdown-menu bg-danger">
						<li class="nav-item">
							<a class="nav-link text-light lead orifont" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
							document.getElementById('logout-form').submit();">
							Logout
						</a>

						<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
							<?php echo e(csrf_field()); ?>

						</form>
					</li>
				</ul>
			</li>
			<?php endif; ?>
		</ul>
	</div>
</nav>

<?php if(Auth::check()): ?>
<div class="container full-height">
	<div class="row">
		<div class="col-lg-4">
			<ul class="list-group">
				<li class="list-group-item">
					<a class="text-dark" href="<?php echo e(route('home')); ?>">Home</a>
				</li>

				<li class="list-group-item">
					<a class="text-dark" href="<?php echo e(route('posts')); ?>">Posts</a>
				</li>

				<li class="list-group-item">
					<a class="text-dark" href="<?php echo e(route('post.create')); ?>">Create new post</a>
				</li>

				<li class="list-group-item">
					<a class="text-dark" href="<?php echo e(route('posts.trashed')); ?>">All trashed posts</a>
				</li>

				<li class="list-group-item">
					<a class="text-dark" href="<?php echo e(route('categories')); ?>">Categories</a>
				</li>

				<li class="list-group-item">
					<a class="text-dark" href="<?php echo e(route('category.create')); ?>">Create new category</a>
				</li>

				<li class="list-group-item">
					<a class="text-dark" href="<?php echo e(route('tags')); ?>">Tags</a>
				</li>

				<li class="list-group-item">
					<a class="text-dark" href="<?php echo e(route('tag.create')); ?>">Create tag</a>
				</li>
			</ul>
		</div>
		<div class="col-lg-8">
			<?php echo $__env->yieldContent('content'); ?>
		</div>			
	</div>
</div>
<?php else: ?>
<?php echo $__env->yieldContent('content'); ?>
<?php endif; ?>

<footer class="bg-danger">
	<div class="container">
		<div class="row py-3">
			<div class="col-sm-6 col-md-6 col-lg-6">
				<p class="lead text-white orifont">Contact Details</p>
				<p class="lead text-white">Ryan Ben S. Villanueva</p>
				<p class="lead text-white"><span><i class="fas fa-mobile-alt"></i></span> 0920-231-2350</p>
				<p class="lead text-white"><span><i class="far fa-envelope"></i></span> foldingbenorigami@gmail.com</p>
			</div>
			<div class="col-sm-6 col-md-6 col-lg-6">
				<p class="lead text-white orifont">Social Media</p>
				<span><a href="https://ryanbenvillanueva.github.io/foldingbenorigami/" target="_blank"><i class="fas fa-home fa-2x text-white pr-4"></i></i></a></span>
				<span><a href="https://www.facebook.com/ryanben.villanueva" target="_blank"><i class="fab fa-facebook fa-2x text-white pr-4"></i></a></span>
				<span><a href="https://www.instagram.com/foldingben/" target="_blank"><i class="fab fa-instagram fa-2x text-white pr-4"></i></a></span>
				<span><a href="https://www.flickr.com/photos/98866450@N03/" target="_blank"><i class="fab fa-flickr fa-2x text-white pr-4"></i></a></span>
				<span><a href="https://www.youtube.com/channel/UCbsGLgXiFBvoOp82_t_q4BA?view_as=subscriber" target="_blank text-white pr-4"><i
					class="fab fa-youtube fa-2x text-white"></i></a></span>
					<div>
						<p class="lead text-white pt-3">Website content and design &copy; 2018 Ryan Ben S. Villanueva</p>
						<a class="pt-2 px-2 btn btn-outline-warning orifont text-white" href="#">Back to Top</a>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- JQuery -->
	<script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
	crossorigin="anonymous"></script>
	<!-- bootstrap popper.js -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
	crossorigin="anonymous"></script>
	<!-- bootstap js -->
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
	crossorigin="anonymous"></script>
	<!-- Toastr Notification js --> 
	<script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>
	<script>
		<?php if(Session::has('success')): ?>
		toastr.success("<?php echo e(Session::get('success')); ?>")
		<?php endif; ?>

		<?php if(Session::has('info')): ?>
		toastr.info("<?php echo e(Session::get('info')); ?>")
		<?php endif; ?>
	</script>
	<!-- WYSIWYG ck-editor js -->
	<script src="<?php echo e(asset('vendor/unisharp/laravel-ckeditor/ckeditor.js')); ?>"></script>
	<script>
		CKEDITOR.replace( 'summary-ckeditor' );
	</script>
</body>

</html>