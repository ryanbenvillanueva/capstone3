@extends('layouts.template')

@section('content')
<div class="container">
	<div class="jumbotron text-center bg-warning orifont m-0">
		<h1><img src="{{ asset('img/logo.png') }}">Blog<img src="{{ asset('img/logo.png') }}"></h1>
	</div>
	<div class="container bg-light">
		<ul class="nav justify-content-around pt-5">
			@foreach ($categories as $category)
			<li class="nav-item text-center">
				<a class="btn btn-lg btn-warning nav-link lead text-dark orifont mx-5" href="#">{{ $category->name }}</a>
			</li>
			@endforeach
		</ul>
	</div>
	<div class="container">
		<div class="row bg-light py-5">
			@foreach($posts as $post)
			<div class="offset-lg-1 col-lg-3">
				<img src="{{ $post->img_path }}" class="card-img-top">
			</div>
			<div class="offset-lg-1 col-lg-7">
				<div class="row">
					<div class="col-lg-8">
						<h3>{{$post->title}}</h3>
						<p>{!!str_limit($post->content, $limit=100)!!}</p>
						<a href="posts/{{$post->id}}" class="btn btn-primary">Read More</a>
						<hr>
					</div>
				</div>
			</div>
			@endforeach
		</div> 
	</div>
</div>
@endsection

