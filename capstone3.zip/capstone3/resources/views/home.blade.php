@extends('layouts.template')

@section('content')
<div class="card">
    <div class="card-heading">
        <h4 class="text-center">Dashboard</h4>
    </div>

    <div class="card-body">
        @if (session('status'))
        <div class="alert alert-success">
            {{ session('status') }}
        </div>
        @endif

        <p class="text-center lead">Welcome!</p>
    </div>
</div>
@endsection
