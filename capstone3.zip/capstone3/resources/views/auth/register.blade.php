@extends('layouts.template')

@section('content')
<div class="container">
    <div class="jumbotron text-center bg-warning orifont">
        <h1><img src="{{ asset('img/logo.png') }}">Register<img src="{{ asset('img/logo.png') }}"></h1>
    </div>
    <div class="row d-flex justify-content-center">
        {{-- <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Register Now</div>

                <div class="panel-body"> --}}
                    <form class="form-horizontal" method="POST" action="{{ route('register') }}">
                        {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('firstname') ? ' has-error' : '' }}">
                            <label for="firstname" class="{{--col-md-4--}}lead orifont control-label">Firstame</label>

                            <div {{--class="col-md-6"--}}>
                                <input id="firstname" type="text" class="form-control" name="firstname" value="{{ old('firstname') }}" required autofocus placeholder="Enter firstname">

                                @if ($errors->has('firstname'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('firstname') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                         <div class="form-group{{ $errors->has('lastname') ? ' has-error' : '' }}">
                            <label for="lastname" class="{{--col-md-4--}}lead orifont control-label">Lastname</label>

                            <div {{--class="col-md-6"--}}>
                                <input id="lastname" type="text" class="form-control" name="lastname" value="{{ old('lastname') }}" required autofocus placeholder="Enter lastname">

                                @if ($errors->has('lastname'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('lastname') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                         <div class="form-group{{ $errors->has('username') ? ' has-error' : '' }}">
                            <label for="username" class="{{--col-md-4--}}lead orifont control-label">Username</label>

                            <div {{--class="col-md-6"--}}>
                                <input id="username" type="text" class="form-control" name="username" value="{{ old('username') }}" required autofocus placeholder="Enter username">

                                @if ($errors->has('username'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('username') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="{{--col-md-4--}}lead orifont control-label">E-Mail Address</label>

                            <div {{--class="col-md-6"--}}>
                                <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" required placeholder="Enter e-mail address">

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="{{--col-md-4--}}lead orifont control-label">Password</label>

                            <div {{--class="col-md-6"--}}>
                                <input id="password" type="password" class="form-control" name="password" required placeholder="Enter password">

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class="{{--col-md-4--}}lead orifont control-label">Confirm Password</label>

                            <div {{--class="col-md-6"--}}>
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required placeholder="Confirm password">
                            </div>
                        </div>

                        <div class="form-group">
                            <div {{--class="col-md-6 col-md-offset-4"--}}>
                                <button type="submit" class="lead orifont btn btn-primary">
                                    Register
                                </button>
                            </div>
                        </div>
                    </form>
                {{-- </div>
            </div>
        </div> --}}
    </div>
</div>
@endsection
